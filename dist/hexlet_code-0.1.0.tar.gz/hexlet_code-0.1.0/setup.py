# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_loader', 'page_loader.scripts']

package_data = \
{'': ['*']}

install_requires = \
['beautifulsoup4>=4.11.1,<5.0.0', 'requests>=2.28.1,<3.0.0']

entry_points = \
{'console_scripts': ['page-loader = page_loader.scripts.page_loader:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Page loader',
    'long_description': '# Page Loader\n### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Alexey-Shepelev/python-project-51/workflows/hexlet-check/badge.svg)](https://github.com/Alexey-Shepelev/python-project-51/actions)\n[![ci-tests](https://github.com/Alexey-Shepelev/python-project-51/actions/workflows/ci-tests.yml/badge.svg)](https://github.com/Alexey-Shepelev/python-project-51/actions/workflows/ci-tests.yml)\n[![Maintainability](https://api.codeclimate.com/v1/badges/50ed7c0038c02a8cd670/maintainability)](https://codeclimate.com/github/Alexey-Shepelev/python-project-51/maintainability)\n[![Test Coverage](https://api.codeclimate.com/v1/badges/50ed7c0038c02a8cd670/test_coverage)](https://codeclimate.com/github/Alexey-Shepelev/python-project-51/test_coverage)\n\n## Demo\n\n### Download webpage\n[![asciicast](https://asciinema.org/a/q7sS4SEBKadNAQDMBh6MfXv6I.svg)](https://asciinema.org/a/q7sS4SEBKadNAQDMBh6MfXv6I)',
    'author': 'Alexey-Shepelev',
    'author_email': 'alexey.sailor@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
