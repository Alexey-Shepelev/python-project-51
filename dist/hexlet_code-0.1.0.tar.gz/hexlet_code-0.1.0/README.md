# Page Loader
### Hexlet tests and linter status:
[![Actions Status](https://github.com/Alexey-Shepelev/python-project-51/workflows/hexlet-check/badge.svg)](https://github.com/Alexey-Shepelev/python-project-51/actions)
[![ci-tests](https://github.com/Alexey-Shepelev/python-project-51/actions/workflows/ci-tests.yml/badge.svg)](https://github.com/Alexey-Shepelev/python-project-51/actions/workflows/ci-tests.yml)
[![Maintainability](https://api.codeclimate.com/v1/badges/50ed7c0038c02a8cd670/maintainability)](https://codeclimate.com/github/Alexey-Shepelev/python-project-51/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/50ed7c0038c02a8cd670/test_coverage)](https://codeclimate.com/github/Alexey-Shepelev/python-project-51/test_coverage)

## Demo

### Download webpage
[![asciicast](https://asciinema.org/a/q7sS4SEBKadNAQDMBh6MfXv6I.svg)](https://asciinema.org/a/q7sS4SEBKadNAQDMBh6MfXv6I)